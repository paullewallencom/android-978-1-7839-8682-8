package com.gradleforandroid.junit;

public class Logic {
    public int add(int a, int b) {
        return a + b;
    }
}
